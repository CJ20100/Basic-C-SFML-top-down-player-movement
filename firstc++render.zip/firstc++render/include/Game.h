#include <SFML/Graphics.hpp>

class Game {
    private:

    sf::Clock dtclock;
    float dt;


    public:

     
    void updateDt();
};




